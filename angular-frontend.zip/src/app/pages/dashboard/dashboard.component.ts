import { Component, OnInit } from '@angular/core';
declare var $: any;
declare var parseInt: any;
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {

    function startTimer(duration, display) {
      let timer = duration, minutes, seconds;
      setInterval(function () {
        minutes = parseInt(timer / 60, 10);
        seconds = parseInt(timer % 60, 10);

        localStorage.setItem('min', minutes);
        localStorage.setItem('sec', seconds);

        let min1 = localStorage.getItem('min');
        let sec1 = localStorage.getItem('sec');
        console.log(min1 + ':' + sec1);


        minutes = minutes < 10 ? '0' + minutes : minutes;
        seconds = seconds < 10 ? '0' + seconds : seconds;

        display.textContent = minutes + ':' + seconds;
        var mytime = 0;
        if (--timer < 0) {
          timer = '';
          var empty = '';
          localStorage.setItem('min', empty);
          localStorage.setItem('sec', empty)
        }
      }, 1000);
    }

    $(document).ready(function () {
      var fiveMinutes = 60 * 1,
        display = document.querySelector('#time');
      //  console.log(display);
      var seconds = localStorage.getItem('sec');
      if (parseInt(seconds) > 0) {
        fiveMinutes = parseInt(seconds);
      }
      else {
        fiveMinutes = fiveMinutes;
      }

      startTimer(fiveMinutes, display);


    });

  }

}
