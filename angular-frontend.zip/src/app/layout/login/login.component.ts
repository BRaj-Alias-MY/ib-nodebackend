import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private router: Router) {

  }

  ngOnInit() {
  }
  login() {
    //alert('testing');
    localStorage.setItem("email", "braj@gmail.com");
    localStorage.setItem('userId','1'); 
    this.router.navigate(['/examboard/entrypage']);
  }
}
