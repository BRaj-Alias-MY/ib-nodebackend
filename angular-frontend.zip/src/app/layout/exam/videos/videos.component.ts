import { Component, OnInit } from '@angular/core';
import { AppService } from '../../../app.service';
@Component({
  selector: 'app-videos',
  templateUrl: './videos.component.html',
  styleUrls: ['./videos.component.css']
})
export class VideosComponent implements OnInit {
  email = localStorage.getItem('email');
  currentInterviewId = localStorage.getItem('currentInterview');
  videosList = [];
  videoURLs: any;
  constructor(private service: AppService) { }

  ngOnInit() {
    this.getVideos();
  }

  getVideos() {
    //alert(this.email);
    this.service.getVideos(this.email, parseInt(this.currentInterviewId)).subscribe(resp => { console.log('hi'); console.log(resp); this.videosList = resp; }, err => console.log(err));

  }


}
