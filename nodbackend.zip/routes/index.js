const MyExam = require ('../controllers/myexam.controller');
const Async = require ('../controllers/asyncinterview.controller');
const AsyncMock = require ('../controllers/asyncmock.controller');
const verify = require ('../middleware/auth').verifyToken;
module.exports = app => {
  // app.get ('/api/all', verify, Company.findAll);
  app.get ('/api/myexam/:InterviewId/:userId/:status', MyExam.findOne);
  app.post ('/api/update2', MyExam.UpdateRecord);
  app.get ('/api/async/:email', Async.findAll);
  app.get ('/api/verifypin/:pin', Async.VerifyPin);
  app.post ('/api/updatepin/', Async.UpdatePin);
  app.get ('/api/asyncmock/:InterviewId', AsyncMock.asyncmock);
  app.get ('/api/getinterviews/:status/:email', Async.findAInterviews);
  app.get ('/api/getvideos/:email/:InterviewId', MyExam.getVideos);
};
