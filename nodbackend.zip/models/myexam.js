'use strict';
module.exports = (sequelize, DataTypes) => {
  const myexam = sequelize.define (
    'myexam',
    {
      InterviewId: DataTypes.INTEGER,
      q_title: DataTypes.STRING,
      ano: DataTypes.INTEGER,
      uid: DataTypes.STRING,
      videoURL: DataTypes.STRING,
      answer: DataTypes.STRING,
      userId: DataTypes.INTEGER,
      email: DataTypes.STRING,
      status: DataTypes.INTEGER,
      max_count: DataTypes.INTEGER,
      time_taken: DataTypes.STRING,
    },
    {}
  );
  myexam.associate = function (models) {
    // associations can be defined here
  };
  return myexam;
};
