'use strict';
module.exports = (sequelize, DataTypes) => {
  const Fee = sequelize.define('Fee', {
    course_id: DataTypes.INTEGER,
    student_id: DataTypes.INTEGER,
    fee: DataTypes.INTEGER
  }, {});
  Fee.associate = function(models) {
    // associations can be defined here
    Fee.belongsTo(models.User, {
      foreignKey: 'id',
      as: 'users'
    });
  };
  return Fee;
};