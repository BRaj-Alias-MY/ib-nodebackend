'use strict';
module.exports = (sequelize, DataTypes) => {
  const Joining = sequelize.define('Joining', {
    course_id: DataTypes.INTEGER,
    student_id: DataTypes.INTEGER
  }, {});
  Joining.associate = function(models) {
    // associations can be defined here
    Joining.belongsTo(models.User, {
      foreignKey: 'id',
      as: 'users'
    });
  };
  return Joining;
};