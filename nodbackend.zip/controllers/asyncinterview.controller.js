const AsyncInterviews = require ('../models').AsyncInterview;
//const jwt = require ('jsonwebtoken');

exports.findAll = (req, res) => {
  //console.log (req.body);
  AsyncInterviews.findAll ({where: {email: req.params.email}})
    .then (result => {
      // Send all customers to Client
      if (result) {
        res.send (result);
      } else {
        res.send ({message: 'no data found!'});
      }
    })
    .catch (err => res.send ('unable to access'));
};

exports.VerifyPin = (req, res) => {
  //console.log (req.body);
  AsyncInterviews.findOne ({where: {pin: req.params.pin}})
    .then (result => {
      // Send all customers to Client
      if (result) {
        res.send (result);
      } else {
        res.send ({message: 'no data found!'});
      }
    })
    .catch (err => res.send ('unable to access'));
};

exports.UpdatePin = (req, res) => {
  console.log (req.body);
  AsyncInterviews.findOne ({
    where: {pin: req.body.pin, email: req.body.email},
  })
    .then (pin => {
      // Send all customers to Client
      if (pin) {
        AsyncInterviews.update (
          {
            status: req.body.status,
          },
          {where: {pin: req.body.pin, email: req.body.email}}
        )
          .then (resp => res.send (resp))
          .catch (err => res.send ('unable to update'));
      } else {
        res.send ({message: 'not updated'});
      }
    })
    .catch (err => res.send ('unable to access'));
};

/*find exams */

exports.findAInterviews = (req, res) => {
  //console.log (req.body);
  AsyncInterviews.findAll ({
    where: {status: 'Completed', email: req.params.email},
  })
    .then (result => {
      // Send all customers to Client
      if (result) {
        res.send (result);
      } else {
        res.send ({message: 'no data found!'});
      }
    })
    .catch (err => res.send ('unable to access'));
};
