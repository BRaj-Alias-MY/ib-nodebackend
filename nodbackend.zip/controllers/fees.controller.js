const Fee = require('../models').Fee;

exports.create = (req, res) => {
    Fee.create ({
      course_id: req.body.course_id,
      student_id: req.body.student_id,
      fee: req.body.fee
    })
      .then (response => {
        res.send (response);
      })
      .catch (err => {
        res.send ('unable to insert! ');
      });
  };