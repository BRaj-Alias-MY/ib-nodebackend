'use strict';
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable ('myexams', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      InterviewId: {
        type: Sequelize.INTEGER,
      },
      q_title: {
        type: Sequelize.STRING,
      },
      ano: {
        type: Sequelize.INTEGER,
      },
      uid: {
        type: Sequelize.STRING,
      },
      answer: {
        type: Sequelize.STRING,
      },
      videoURL: {
        type: Sequelize.STRING,
      },
      userId: {
        type: Sequelize.INTEGER,
      },
      email: {
        type: Sequelize.STRING,
      },
      status: {
        type: Sequelize.INTEGER,
      },
      max_count: {
        type: Sequelize.INTEGER,
      },
      time_taken: {
        type: Sequelize.STRING,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
      },
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable ('myexams');
  },
};
